# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'bed32b9e1b1705f2a5284cc1ffd78240c04e2139096fc073b07487beb8c324af211918060ad6a97acfd9e5dbd63f263cea6c9f6dca9acfc8b32872e19fe3d5bc'