Rack::MiniProfiler.config.start_hidden = true
