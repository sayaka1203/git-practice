//= link_tree ../images
//= link_directory ../stylesheets .css
//= link no_image.jpg
//= link application.js